<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>Glance Design Dashboard an Admin Panel Category Flat Bootstrap Responsive Website Template | Forms :: w3layouts</title>
<head>
    @include('admin/layouts/head')
</head>
<body class="cbp-spmenu-push">
	<div class="main-content">
    @include('admin/layouts/menu')

    </div>
<!-- main content start-->
<div id="page-wrapper">
			<div class="main-page">
				<div class="forms">
					<h2 class="title1">Forms</h2>
					<div class="row">
						<h3 class="title1">General Form :</h3>
						<div class="form-three widget-shadow">
							<form class="form-horizontal" action={{ route("admin.villas.store") }} method="POST">
                            {{ csrf_field() }}
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Villa Name</label>
									<div class="col-sm-8">
										<input type="text" class="form-control1" id="villa_name" placeholder="Villa Name" name="villa_name">
									</div>
									<div class="col-sm-2">
										<p class="help-block">Your help text!</p>
									</div>
                                </div>

                                <div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Slug</label>
									<div class="col-sm-8">
										<input type="text" class="form-control1" id="villa_slug" placeholder="Villa Slug" name="villa_slug">
									</div>
									<div class="col-sm-2">
										<p class="help-block">Your help text!</p>
									</div>
								</div>
                                
                                <div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Villa Cost</label>
									<div class="col-sm-8">
										<input type="text" class="form-control1" id="villa_cost" placeholder="Villa Cost" name="villa_cost">
									</div>
									<div class="col-sm-2">
										<p class="help-block">Your help text!</p>
									</div>
                                </div>
                                
                                <div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Villa Location</label>
									<div class="col-sm-8">
										<input type="text" class="form-control1" id="villa_location" placeholder="Villa Location" name="villa_location">
									</div>
									<div class="col-sm-2">
										<p class="help-block">Your help text!</p>
									</div>
                                </div>
                                
                                <div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Villa State</label>
									<div class="col-sm-8">
										<input type="text" class="form-control1" id="villa_name" placeholder="Villa State" name="villa_state">
									</div>
									<div class="col-sm-2">
										<p class="help-block">Your help text!</p>
									</div>
								</div>
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Villa Address</label>
									<div class="col-sm-8">
                                        
                                        <textarea class="form-control" id="villa_address" name="villa_address" id="villa_address"> </textarea>
									</div>
									<div class="col-sm-2">
										<p class="help-block">Your help text!</p>
									</div>
                                </div>
                                <div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Villa Description</label>
									<div class="col-sm-8">
                                        
                                        <textarea class="form-control" id="villa_description" name="villa_description" id="villa_address"> </textarea>
									</div>
									<div class="col-sm-2">
										<p class="help-block">Your help text!</p>
									</div>
                                </div>
                                
                                <div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Contact Manager</label>
									<div class="col-sm-8">
										<input type="text" class="form-control1" id="villa_manager" placeholder="Villa Manager" name="villa_manager">
									</div>
									<div class="col-sm-2">
										<p class="help-block">Your help text!</p>
									</div>
								</div>
								<div class="form-group">
									<label for="checkbox" class="col-sm-2 control-label">Features</label>
									<div class="col-sm-8">
										<div class="checkbox-inline1"><label><input type="checkbox"> Unchecked</label></div>
										<div class="checkbox-inline1"><label><input type="checkbox" checked=""> Checked</label></div>
										<div class="checkbox-inline1"><label><input type="checkbox" disabled=""> Disabled Unchecked</label></div>
										<div class="checkbox-inline1"><label><input type="checkbox" disabled="" checked=""> Disabled Checked</label></div>
									</div>
                                </div>
                                <div class="form-group">
									<label for="checkbox" class="col-sm-2 control-label">Amenities</label>
									<div class="col-sm-8">
										<div class="checkbox-inline1"><label><input type="checkbox"> Unchecked</label></div>
										<div class="checkbox-inline1"><label><input type="checkbox" checked=""> Checked</label></div>
										<div class="checkbox-inline1"><label><input type="checkbox" disabled=""> Disabled Unchecked</label></div>
										<div class="checkbox-inline1"><label><input type="checkbox" disabled="" checked=""> Disabled Checked</label></div>
									</div>
								</div>
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Sleeps </label>
									<div class="col-sm-8">
										<input type="text" class="form-control1" id="villa_sleep" placeholder="Villa Sleep" name="villa_sleep">
									</div>
									<div class="col-sm-2">
										<p class="help-block">Your help text!</p>
									</div>
								</div>
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Bedroom</label>
									<div class="col-sm-8">
										<input type="text" class="form-control1" id="villa_bedroom" placeholder="Villa Bedroom" name="villa_bedroom">
									</div>
									<div class="col-sm-2">
										<p class="help-block">Your help text!</p>
									</div>
								</div>
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Bathrooms</label>
									<div class="col-sm-8">
										<input type="text" class="form-control1" id="villa_bathrooms" placeholder="Villa Bathrooms" name="villa_bathrooms">
									</div>
									<div class="col-sm-2">
										<p class="help-block">Your help text!</p>
									</div>
								</div>
								<input type="submit" class="btn btn-success" value="save">
							</form>
						</div>
					</div>
					
			</div>
        </div>
        
        @include('admin/layouts/menu')

</body>
</html>
		